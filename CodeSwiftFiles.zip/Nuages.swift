//
//  Nuages.swift
//  Balloon
//
//  Copyright © 2016 Mattieu BERNARD-GUÊLE. All rights reserved.
//
import Foundation
import SpriteKit

class Nuages : SKSpriteNode {
    var isFinish : Bool = true
    init(texture: SKTexture?, nom: String, pos: CGPoint, size: CGFloat) {
        super.init(texture: texture, color: UIColor.blackColor(), size: texture!.size())
        self.name = nom
        self.position = pos
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
