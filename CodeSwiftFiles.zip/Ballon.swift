//
//  Ballon.swift
//  SnakOs2.0
//
//  Copyright © 2016 Mattieu BERNARD-GUÊLE. All rights reserved.
//

import Foundation
import SpriteKit

class Ballon : SKSpriteNode {
    var sonExplosion : String = ""
    var gamer : Player = getStatGamer()
    var speedUp : UInt32 = 0
    
    init(texture: SKTexture?, nom: String, pos: CGPoint, size: CGFloat, level: Int) {
        super.init(texture: texture, color: UIColor.blackColor(), size: texture!.size())
        
        var sizeB = randIntervalPositif(21, diff: 40, isForNeg: false)
        sizeB /= 100
        switch gamer.level {
        case 1:
            speedUp = 0
            break
        case 2:
            speedUp = 0
            break
        case 3:
            speedUp = 1
            break
        case 4:
            speedUp = 1
            break
        case 5:
            speedUp = 2
            break
        default:
            break
        }
        self.xScale = sizeB
        self.yScale = sizeB
        
        if (nom.containsString("vert"))
        {
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(6, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 4, isForNeg: false ))))
            self.zPosition = 4
            self.position = pos
            self.name = "vert"
            //self.runAction(SKAction.playSoundFileNamed("click.wav", waitForCompletion: false))
            //sprite.xScale = 0.5
            //sprite.yScale = 0.5
        }
        if (nom.containsString("rouge"))
        {
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(6, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 4, isForNeg: false))))
            self.zPosition = 4
            self.position = pos
            self.name = "rouge"
            //sprite.xScale = 0.5
            //sprite.yScale = 0.5
        }
        if (nom.containsString("bleue"))
        {
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(6, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 4, isForNeg: false))))
            self.zPosition = 4
            self.position = pos
            self.name = "bleue"
            //sprite.xScale = 0.5
            //sprite.yScale = 0.5
        }
        if (nom.containsString("jaune"))
        {
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(6, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 4, isForNeg: false))))
            self.zPosition = 4
            self.position = pos
            self.name = "jaune"
            //sprite.xScale = 0.5
            //sprite.yScale = 0.5
        }
        if (nom.containsString("gris"))
        {
            self.xScale = 0.75
            self.yScale = 0.75
            
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(26, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(4, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(4 - speedUp, diff: 7, isForNeg: false))))
            self.zPosition = 2
            self.position = pos
            self.name = "gris"
        }
        if (nom.containsString("rose"))
        {
            self.xScale = 0.30
            self.yScale = 0.30
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 40, isForNeg: false), timePeriod: randIntervalPositif(3, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 2, isForNeg: false))))
            self.zPosition = 3
            self.position = pos
            self.name = "rose"
        }
    }
    
    
    init(texture: SKTexture?, nom: String, pos: CGPoint, size: CGFloat, level: Int, zpos: CGFloat) {
        super.init(texture: texture, color: UIColor.blackColor(), size: texture!.size())
        
        var sizeB = randIntervalPositif(21, diff: 40, isForNeg: false)
        sizeB /= 100
        self.xScale = sizeB
        self.yScale = sizeB
        
        if (nom.containsString("vert"))
        {
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(6, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 4, isForNeg: false ))))
            self.zPosition = zpos
            self.position = pos
            self.name = "ballon"
        }
        if (nom.containsString("rouge"))
        {
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(6, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 4, isForNeg: false))))
            self.zPosition = zpos
            self.position = pos
            self.name = "ballon"
        }
        if (nom.containsString("bleue"))
        {
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(6, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 4, isForNeg: false))))
            self.zPosition = zpos
            self.position = pos
            self.name = "ballon"
        }
        if (nom.containsString("jaune"))
        {
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(6, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 4, isForNeg: false))))
            self.zPosition = zpos
            self.position = pos
            self.name = "ballon"
        }
        if (nom.containsString("gris"))
        {
            self.xScale = 0.75
            self.yScale = 0.75
            
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(26, diff: 0, isForNeg: false), timePeriod: randIntervalPositif(4, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(4 - speedUp, diff: 7, isForNeg: false))))
            self.zPosition = zpos
            self.position = pos
            self.name = "ballon"
        }
        if (nom.containsString("rose"))
        {
            self.xScale = 0.30
            self.yScale = 0.30
            let oscillate = SKAction.oscillation(amplitude: randIntervalPositif(41, diff: 40, isForNeg: false), timePeriod: randIntervalPositif(3, diff: 1, isForNeg: false), midPoint: pos)
            self.runAction(SKAction.repeatActionForever(oscillate))
            self.runAction(SKAction.moveByX(0, y: size, duration: NSTimeInterval(randIntervalPositif(3 - speedUp, diff: 2, isForNeg: false))))
            self.zPosition = zpos
            self.position = pos
            self.name = "ballon"
        }
    }
    
    init(texture: SKTexture?, nom: String, pos: CGPoint, size: CGFloat, level: Int, zpos: CGFloat, toGo: CGPoint) {
        super.init(texture: texture, color: UIColor.blackColor(), size: texture!.size())
        self.xScale = 0.4
        self.yScale = 0.4
        self.zPosition = zpos
        self.name = "ballon"
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}