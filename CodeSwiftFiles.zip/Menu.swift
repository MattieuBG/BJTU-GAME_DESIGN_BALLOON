//
//  MenuController.swift
//  SnakOs2.0
//
//  Copyright © 2016 Mattieu BERNARD-GUÊLE. All rights reserved.
//

import UIKit
import SpriteKit
import AVFoundation
import AudioToolbox

class Menu: SKScene {
    let myLabel = SKLabelNode(fontNamed:"Copperplate-Bold")
    
    var player : Player = Player()
    var allNuages : [Nuages] = []
    var difficulty : [Difficulty] = []
    var menuItem: [MenuItem] = []
    var tabBallon: [Ballon] = []
    var tabBallonHighscore: [Ballon] = []
    var tabBallonLabel: [SKLabelNode] = []
    var tabColor: [String] = ["rouge", "vert", "bleu", "jaune"]
    var tabStr : [String] = ["Easy","Easy-Medium","Medium","Medium-High","High"]
    var HighScoreKeyStandart: String = "HighScoreKey1"
    var HighScoreKeyPrecision: String = "HighScorePrecision1"
    var HighScoreKeySurvie: String = "HighScoreKeySurvie1"
    
    var level : Int = 0
    var prevLevel : Int = 0
    var cgfloat : CGFloat = 0.0
    let offset : CGFloat = 50
    let toFly : CGFloat = 750
    var finish : Bool = false
    var areShow : Bool = false
    var canSwipe : Bool = true
    var changeLab : Bool = true
    var time : CGFloat = 0
    
    var toGo1 : CGPoint = CGPointMake(0, 0)
    var toGo2 : CGPoint = CGPointMake(0, 0)
    var toGo3 : CGPoint = CGPointMake(0, 0)
    var pos1 : CGPoint = CGPointMake(0, 0)
    var pos2 : CGPoint = CGPointMake(0, 0)
    var pos3 : CGPoint = CGPointMake(0, 0)
    
    override func didMoveToView(view: SKView) {
        /* Setup your scene here */
        
        //Background
        
        let backgroundImage = init_back("ciel")
        self.addChild(backgroundImage)
        
        //Label
        
        myLabel.text = "Easy"
        myLabel.fontColor = SKColor.blackColor()
        myLabel.fontSize = 30
        myLabel.position = CGPointMake(frame.width / 2, frame.height / 4.2 - offset - 30)
        myLabel.zPosition = 2
        myLabel.hidden = true
        self.addChild(myLabel)
        
        //Music en background
        
        init_sound("menu", ext: "mp3")
        initSwiping(view)
        
        //Initialisation de "Difficulty"
        
        var i : CGFloat = 80
        for index in 1...5 {
            let pos = CGPointMake(frame.width / 2 - i, frame.height / 3.2 - offset - 20 - toFly)
            i = i - 40
            var item : Difficulty
            if (index == 1) {
                item = Difficulty(texture: SKTexture(imageNamed:"star-empty"), nom: "star\(index)", pos: pos, size: size.width)
                item.texture = SKTexture(imageNamed: "star-fill\(index)")
                prevLevel = 1
                level = 1
            }
            else {
                item = Difficulty(texture: SKTexture(imageNamed:"star-empty"), nom: "star\(index)", pos: pos, size: size.width)
            }
            item.level = tabStr[index - 1]
            item.zPosition = 2
            item.xScale = 0.2
            //0.2 au lieu de 0.4 en aspect Fill et i = 40
            item.yScale = 0.2
            item.userInteractionEnabled = false
            let toGo = CGPointMake(size.width/2, size.height/1.5)
            let oscillate = SKAction.oscillation(amplitude: 10, timePeriod: 2, midPoint: pos)
            item.runAction(SKAction.repeatActionForever(oscillate))
            item.runAction(SKAction.moveByX(0, y: toGo.x + 230, duration: 5),completion : {self.myLabel.hidden = false})
            item.starCount = index
            difficulty.append(item)
        }
        
        // INIT NUAGE
        
        for index in 1...6 {
            cgfloat = randIntervalPositif(650, diff: 40, isForNeg: false)
            let randomize = randIntervalPositif(10, diff: 1, isForNeg: false)
            var pos = CGPointMake(30, cgfloat)
            if (randomize % 2 == 0) {
                pos = CGPointMake(30, cgfloat)
            }
            else {
                pos = CGPointMake(1000, cgfloat)
            }
            let nuage = Nuages(texture: SKTexture(imageNamed:"nu\(index)"), nom: "nuage\(index)", pos: pos, size: size.width)
            nuage.zPosition = 1
            nuage.xScale = 3
            nuage.yScale = 3
            allNuages.append(nuage)
        }
        
        // INIT MENU
        
        var inc : CGFloat = -100
        for index in 1...6 {
            var pos = CGPointMake(size.width/2, size.height/1.5 - inc - toFly)
            var toGo = CGPointMake(size.width/2, size.height/1.5 - inc)
            //            let oscillate = SKAction.oscillation(amplitude: 5, timePeriod: 1, midPoint: pos)
            //            self.runAction(SKAction.repeatActionForever(oscillate))
            //            self.runAction(SKAction.moveByX(0, y: toGo.y, duration: 5))
            if (index == 1) {
                toGo = CGPointMake(size.width/2 + 53, size.height/1.5 + 137 - offset)
                pos = CGPointMake(size.width/2 + 53, size.height/1.5 + 137 - offset - toFly)
                inc += 100
                let menu_item = MenuItem(texture: SKTexture(imageNamed:"item\(index)"), nom: "item\(index)", pos: pos, size: size.width, text: "ballon1", isSelected: false, isSelectable: false)
                menu_item.zPosition = 3
                menu_item.xScale = 1
                menu_item.yScale = 1
                menu_item.userInteractionEnabled = false
                let oscillate = SKAction.oscillation(amplitude: 5, timePeriod: 1, midPoint: pos)
                menu_item.runAction(SKAction.repeatActionForever(oscillate))
                menu_item.runAction(SKAction.moveByX(0, y: toGo.x - 53 + 230, duration: 5))
                menuItem.append(menu_item)
            }
            else if (index == 2) {
                toGo = CGPointMake(size.width/2 - 68, size.height/1.5 + 137 - offset)
                pos = CGPointMake(size.width/2 - 68, size.height/1.5 + 137 - offset - toFly)
                let menu_item = MenuItem(texture: SKTexture(imageNamed:"item1a"), nom: "item\(index)", pos: pos, size: size.width, text: "ballon2", isSelected: false, isSelectable: false)
                menu_item.zPosition = 6
                menu_item.xScale = 1
                menu_item.yScale = 1
                menu_item.userInteractionEnabled = false
                let oscillate = SKAction.oscillation(amplitude: 5, timePeriod: 1, midPoint: pos)
                menu_item.runAction(SKAction.repeatActionForever(oscillate))
                menu_item.runAction(SKAction.moveByX(0, y: toGo.x + 68 + 230, duration: 5))
                menuItem.append(menu_item)
            }
            else {
                var selectable : Bool = true
                var selected : Bool = false
                var img : String = "item\(index - 1)"
                var name : String = "item\(index)"
                var text : String = ""
                if (index == 3) {
                    toGo = CGPointMake(size.width/2, size.height/1.5 - offset)
                    pos = CGPointMake(size.width/2, size.height/1.5 - offset - toFly)
                    selectable = false
                    text = "jouer"
                }
                else if (index == 4){
                    toGo = CGPointMake(size.width/2, size.height/1.5 - inc - offset)
                    pos = CGPointMake(size.width/2, size.height/1.5 - inc - offset - toFly)
                    selected = true
                    img = "item\(index - 1)s"
                    name = "item\(index)s"
                    text = "standart"
                    pos1 = pos
                    pos1.x += 150
                    toGo1 = toGo
                    toGo1.x += 150
                    
                }
                else {
                    if (index == 5) {
                        toGo = CGPointMake(size.width/2 - 72, size.height/1.5 - inc - offset)
                        pos = CGPointMake(size.width/2 - 72, size.height/1.5 - inc - offset - toFly)
                        text = "precision"
                        img = "item\(index-1)g"
                        pos2 = pos
                        pos2.x -= 78
                        toGo2 = toGo
                        toGo2.x -= 78
                    }
                    else if (index == 6)
                    {
                        toGo = CGPointMake(size.width/2 + 68, size.height/1.5 - inc - offset)
                        pos = CGPointMake(size.width/2 + 68, size.height/1.5 - inc + offset - toFly)
                        text = "survie"
                        img = "item\(index-2)d"
                        pos3 = pos
                        pos3.x += 82
                        toGo3 = toGo
                        toGo3.x += 82
                    }
                    
                }
                let menu_item = MenuItem(texture: SKTexture(imageNamed:img), nom: name, pos: pos, size: size.width,text: text, isSelected: selected, isSelectable: selectable)
                let oscillate = SKAction.oscillation(amplitude: 5, timePeriod: 1, midPoint: pos)
                menu_item.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                
                if (index == 6)
                {
                    menu_item.runAction(SKAction.moveByX(0, y: toGo.x + 230 - 68, duration: 5),completion : {menu_item.isSelectable = true})
                    inc += 0
                }
                else if (index == 5)
                {
                    menu_item.runAction(SKAction.moveByX(0, y: toGo.x + 230 + 72, duration: 5),completion : {menu_item.isSelectable = true})
                    inc += 100
                }
                else
                {
                    menu_item.runAction(SKAction.moveByX(0, y: toGo.x + 230, duration: 5),completion : {menu_item.isSelectable = true})
                    inc += 100
                }
                menu_item.zPosition = 4
                menu_item.xScale = 1.4
                menu_item.yScale = 1.2
                
                menuItem.append(menu_item)
            }
        }
        
        difficulty.forEach { (item: Difficulty) -> () in
            self.addChild(item)
        }
        allNuages.forEach { (item: Nuages) -> () in
            self.addChild(item)
        }
        menuItem.forEach { (item: MenuItem) -> () in
            self.addChild(item)
        }
        //setNuages(allNuages)
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        /* Called when a touch begins */
        
        
        
        for touch in touches {
            let location = touch.locationInNode(self)
            let node = self.nodeAtPoint(location)
            let nodes = self.nodesAtPoint(location)
            
            if (node.name == "item2")
            {
                nodes.forEach({ (item: SKNode) -> () in
                    if item.name == "item3"
                    {
                        menuItem.forEach({ (item: MenuItem) -> () in
                            if item.name == "item3" {
                                if (item.isSelectable == true) {
                                    playIt(item, x: item.position.x, y: item.position.y)
                                }
                                else {
                                    item.runAction(SKAction.playSoundFileNamed("tick.mp3", waitForCompletion: false))
                                }
                            }
                        })
                    }
                })
            }
            if (node.name == "item2" || node.name == "item1")
            {
                menuItem.forEach({ (item: MenuItem) -> () in
                    if item.name == "item2" {
                        let i = randIntervalPositif(3, diff: 1, isForNeg: false)
                        item.runAction(SKAction.playSoundFileNamed("bruitballon\(Int(i)).mp3", waitForCompletion: true))
                    }
                })
            }
            if (node.name == "item3") {
                menuItem.forEach({ (item: MenuItem) -> () in
                    if item.name == "item3" {
                        if (item.isSelectable == true) {
                            playIt(item, x: item.position.x, y: item.position.y)
                        }
                        else {
                            item.runAction(SKAction.playSoundFileNamed("tick.mp3", waitForCompletion: false))
                        }
                    }
                })
            }
            else if (node.name?.containsString("item4") == true)
            {
                menuItem.forEach({ (item: MenuItem) -> () in
                    if item.name == "item4" {
                        menuItem.forEach({ (elem: MenuItem) -> () in
                            if (elem.name == "item5s")
                            {
                                elem.texture = SKTexture(imageNamed: "item4g")
                                elem.name = "item5"
                                elem.isSelected = false
                            }
                            else if (elem.name == "item6s")
                            {
                                elem.texture = SKTexture(imageNamed: "item4d")
                                elem.name = "item6"
                                elem.isSelected = false
                                
                            }
                        })
                        item.texture = SKTexture(imageNamed: "item3s")
                        item.name = "item4s"
                        item.isSelected = true
                    }
                    else if item.name == "item4s" {
                        //                        item.texture = SKTexture(imageNamed: "item3")
                        //                        item.name = "item4"
                        //                        item.isSelected = false
                    }
                })
            }
            else if (node.name?.containsString("item5") == true)
            {
                menuItem.forEach({ (item: MenuItem) -> () in
                    if item.name == "item5" {
                        menuItem.forEach({ (elem: MenuItem) -> () in
                            if (elem.name == "item4s")
                            {
                                elem.texture = SKTexture(imageNamed: "item3")
                                elem.name = "item4"
                                elem.isSelected = false
                            }
                            else if (elem.name == "item6s")
                            {
                                elem.texture = SKTexture(imageNamed: "item4d")
                                elem.name = "item6"
                                elem.isSelected = false
                                
                            }
                        })
                        item.texture = SKTexture(imageNamed: "item4gs")
                        item.name = "item5s"
                        item.isSelected = true
                    }
                    else if item.name == "item5s" {
                        //                        item.texture = SKTexture(imageNamed: "item4")
                        //                        item.name = "item5"
                        //                        item.isSelected = false
                    }
                })
            }
            else if (node.name?.containsString("item6") == true)
            {
                menuItem.forEach({ (item: MenuItem) -> () in
                    if item.name == "item6" {
                        menuItem.forEach({ (elem: MenuItem) -> () in
                            if (elem.name == "item4s")
                            {
                                elem.texture = SKTexture(imageNamed: "item3")
                                elem.name = "item4"
                                elem.isSelected = false
                            }
                            else if (elem.name == "item5s")
                            {
                                elem.texture = SKTexture(imageNamed: "item4g")
                                elem.name = "item5"
                                elem.isSelected = false
                                
                            }
                        })
                        item.texture = SKTexture(imageNamed: "item4ds")
                        item.name = "item6s"
                        item.isSelected = true
                    }
                    else if item.name == "item5s" {
                        //                        item.texture = SKTexture(imageNamed: "item4")
                        //                        item.name = "item5"
                        //                        item.isSelected = false
                    }
                })
            }
            else if ((node.name?.containsString("star")) == true)
            {
                var boucle = 1
                var choisi = false
                changeLab = true
                difficulty.forEach({ (item: Difficulty) -> () in
                    if (item.name == node.name) {
                        prevLevel = level
                        level = boucle
                        item.texture = SKTexture(imageNamed: "star-fill\(boucle)")
                        myLabel.text = item.level
                        if (prevLevel < level) {
                            item.runAction(SKAction.playSoundFileNamed("gonfle.mp3", waitForCompletion: false))
                        }
                        else if (prevLevel > level) {
                            item.runAction(SKAction.playSoundFileNamed("boom.mp3", waitForCompletion: false))
                        }
                        else if (prevLevel == level) {
                            item.runAction(SKAction.playSoundFileNamed("bruitballon1.mp3", waitForCompletion: false))
                        }
                        choisi = true
                    }
                    else if (choisi == true) {
                        item.texture = SKTexture(imageNamed: "star-empty")
                    }
                    else if (choisi == false) {
                        item.texture = SKTexture(imageNamed: "star-fill\(boucle)")
                    }
                    boucle++;
                })
                var count : Int = 1
                difficulty.forEach({ (item: Difficulty) -> () in
                    
                    if (count <= level) {
                        item.texture = SKTexture(imageNamed: "star-fill\(level)")
                    }
                    else {
                        item.texture = SKTexture(imageNamed: "star-empty")
                    }
                    count++;
                })
            }
            if (node.name == "ballon")
            {
                node.runAction(SKAction.playSoundFileNamed("bruitballon1.mp3", waitForCompletion: false))
            }
        }
    }
    
    
    func playIt(button: SKSpriteNode, x: CGFloat, y: CGFloat)
    {
        let exp1 = SKTexture(imageNamed: "item2s")
        let exp2 = SKTexture(imageNamed: "item2")
        
        let animatebtn = SKAction.sequence([
            SKAction.waitForDuration(0, withRange: 0),
            SKAction.animateWithTextures([exp1,exp2], timePerFrame: 0.3)
            ])
        button.runAction(SKAction.playSoundFileNamed("click.mp3", waitForCompletion: false))
        button.runAction(animatebtn, completion : {button.runAction(SKAction.playSoundFileNamed("click2.mp3", waitForCompletion: false))
            
            self.menuItem.forEach({ (item: MenuItem) -> () in
                if (item.isSelected == true && (item.name == "item4s" || item.name == "item5s" || item.name == "item6s"))
                {
                    self.player.gameMode = item.text
                    self.player.level = self.level
                }
            })
            self.goPlayAnimate()
            self.finish = true;
        })
    }
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
        
        if (self.finish == true) {
            menuItem.forEach({ (item: MenuItem) -> () in
                if (item.text == "jouer")
                {
                    if (item.position.y < -100) {
                        self.changeScene()
                    }
                }
            })
            
        }
        if (prevLevel != level || changeLab == true)
        {
            if (changeLab == true)
            {
                HighScoreKeyStandart = "HighScoreKey" + "\(level)"
                HighScoreKeyPrecision = "HighScoreKeyPrecision" + "\(level)"
                HighScoreKeySurvie = "HighScoreKeySurvie" + "\(level)"
            }
            changeLab = false
        }
        
        allNuages.forEach { (item: Nuages) -> () in
            cgfloat = randIntervalPositif(650, diff: 40, isForNeg: false)
            let duration : NSTimeInterval = NSTimeInterval(randIntervalPositif(21, diff: 4, isForNeg: false))
            let ampli : CGFloat = randIntervalPositif(4, diff: 1, isForNeg: false)
            
            if (item.position.x >= CGFloat(950) && item.name?.containsString("1") == nil && item.isFinish == true){
                goLeftOrRight(item, rand: cgfloat, ampli: ampli, time: 5, mid: CGPointMake(item.position.x, cgfloat), x: 0, duration: duration)
            }
            else if (item.position.x >= CGFloat(1000) && item.isFinish == true){
                goLeftOrRight(item, rand: cgfloat, ampli: ampli, time: 5, mid: CGPointMake(item.position.x, cgfloat), x: 0, duration: duration)
            }
            if (item.position.x <= CGFloat(50) && item.isFinish == true){
                goLeftOrRight(item, rand: cgfloat, ampli: ampli, time: 5, mid: CGPointMake(item.position.x, cgfloat), x: 1024, duration: duration)
            }
            if (item.position.x >= CGFloat(100) && item.position.x <= CGFloat(900)){
                item.isFinish = true
            }
        }
        
        if (time % randIntervalPositif(21, diff: 40, isForNeg: false)  == 0)
        {
            if (randIntervalPositif(131, diff: 0, isForNeg: false) % 3 == 0/*time % 40 == 0*/)
            {
                let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                let pos = CGPointMake(cgfloat, -55)
                tabBallon.append(Ballon(texture: SKTexture(imageNamed:"vert"), nom: "vert", pos: pos, size: size.width, level: 1, zpos: 1))
                self.addChild(tabBallon.last!)
            }
            else if (randIntervalPositif(131, diff: 0, isForNeg: false) % 3 == 0/*time % 30 == 0*/)
            {
                let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                let pos = CGPointMake(cgfloat, -55)
                tabBallon.append(Ballon(texture: SKTexture(imageNamed:"bleu"), nom: "bleue", pos: pos, size: size.width, level: 1, zpos: 1))
                self.addChild(tabBallon.last!)
            }
            else if (randIntervalPositif(131, diff: 0, isForNeg: false) % 3 == 0/*time % 35 == 0*/)
            {
                let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                let pos = CGPointMake(cgfloat, -55)
                tabBallon.append(Ballon(texture: SKTexture(imageNamed:"jaune"), nom: "jaune", pos: pos, size: size.width, level: 1, zpos: 1))
                self.addChild(tabBallon.last!)
            }
            else if (randIntervalPositif(131, diff: 0, isForNeg: false) % 3 == 0/*time % 50 == 0*/)
            {
                let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                let pos = CGPointMake(cgfloat, -55)
                tabBallon.append(Ballon(texture: SKTexture(imageNamed:"rouge"), nom: "rouge", pos: pos, size: size.width, level:1, zpos: 1))
                self.addChild(tabBallon.last!)
            }
            else if (randIntervalPositif(131, diff: 0, isForNeg: false) % 11 == 0/*time % 45 == 0*/)
            {
                let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                let pos = CGPointMake(cgfloat, -60)
                tabBallon.append(Ballon(texture: SKTexture(imageNamed:"rose"), nom: "rose", pos: pos, size: size.width, level: 1, zpos: 1))
                self.addChild(tabBallon.last!)
            }
            else if (randIntervalPositif(141, diff: 0, isForNeg: false) % 7 == 0/*time % 25 == 0*/)
            {
                let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                let pos = CGPointMake(cgfloat, -80)
                tabBallon.append(Ballon(texture: SKTexture(imageNamed:"gris"), nom: "gris", pos: pos, size: size.width, level: 1, zpos: 1))
                self.addChild(tabBallon.last!)
            }
        }
        time++
        
    }
    
    func goLeftOrRight(obj: Nuages, rand: CGFloat, ampli : CGFloat, time: CGFloat, mid: CGPoint, x: CGFloat, duration: NSTimeInterval) -> Void
    {
        obj.removeAllActions()
        let pos = CGPointMake(obj.position.x, cgfloat)
        obj.position = pos
        obj.isFinish = false
        let oscillate = SKAction.oscillationHorizontale(amplitude: ampli, timePeriod: time, midPoint: mid)
        obj.runAction(SKAction.repeatActionForever(oscillate))
        obj.runAction(SKAction.moveToX(x, duration: duration))
    }
    
    func init_back(name: String) -> SKSpriteNode
    {
        let bgImage = SKSpriteNode(imageNamed: name)
        bgImage.position = CGPointMake(self.size.width/2, self.size.height/2)
        bgImage.size = CGSizeMake(self.frame.size.width, self.frame.size.height)
        bgImage.zPosition = 0
        return bgImage
    }
    
    func witchIsSelected() -> String
    {
        var str : String = ""
        menuItem.forEach { (item : MenuItem) -> () in
            if (item.isSelected == true) {
                str = item.text
            }
        }
        return str
    }
    
    func goPlayAnimate() -> Void
    {
        menuItem.forEach { (item: MenuItem) -> () in
            if (item.text.containsString("ballon") == true) {
                explose(item, x: 1, y: 1)
                item.removeFromParent()
            }
        }
    }
    
    func explose(ballon: SKSpriteNode, x: CGFloat, y: CGFloat)
    {
        let exp1 = SKTexture(imageNamed: "exp1")
        let exp2 = SKTexture(imageNamed: "exp2")
        let exp3 = SKTexture(imageNamed: "exp3")
        let exp4 = SKTexture(imageNamed: "exp4")
        let exp5 = SKTexture(imageNamed: "exp5")
        let exp6 = SKTexture(imageNamed: "exp6")
        
        let animateExplosion = SKAction.sequence([
            SKAction.waitForDuration(0, withRange: 0),
            SKAction.animateWithTextures([exp1,exp2,exp3,exp4,exp5,exp6], timePerFrame: 0.05)
            ])
        
        let Explosion = SKSpriteNode(imageNamed: "exp1")
        Explosion.xScale = x
        Explosion.yScale = y
        Explosion.zPosition = 4
        Explosion.position = CGPointMake(ballon.position.x, ballon.position.y + 10)
        Explosion.runAction(SKAction.playSoundFileNamed("boom.mp3", waitForCompletion: false))
        self.addChild(Explosion)
        Explosion.runAction(animateExplosion, completion : {Explosion.removeFromParent()})
        difficulty.forEach { (item: Difficulty) -> () in
            item.runAction(SKAction.moveByX(0, y: -300, duration:2))
        }
        tabBallon.forEach { (item: Ballon) -> () in
            if (item.position.y <= 0 || item.position.x <= 0) {
                item.removeFromParent()
            }
            item.runAction(SKAction.moveByX(0, y: +1000, duration:2))
        }
        if (areShow == true)
        {
            tabBallonHighscore.forEach { (item: Ballon) -> () in
                item.runAction(SKAction.moveByX(0, y: +1000, duration:2))
            }
            tabBallonLabel.forEach({ (item: SKLabelNode) -> () in
                item.runAction(SKAction.moveByX(0, y: +1000, duration:2))
            })
        }
        myLabel.runAction(SKAction.moveByX(0, y: -800, duration:3))
        setNuages(allNuages)
        
        menuItem.forEach { (item: MenuItem) -> () in
            item.runAction(SKAction.moveByX(0, y: -800, duration:3))
        }
        
    }
    
    func changeScene()
    {
        self.allNuages.forEach({ (item: Nuages) -> () in
            item.removeFromParent()
        })
        if (player.gameMode == "standart" || player.gameMode == "survie")
        {
            let scene:SKScene = GameScene(size: self.size)
            setStatGamer(self.player)
            scene.scaleMode = .AspectFill
            self.view?.presentScene(scene)
        }
        else if (player.gameMode == "precision")
        {
            let scene:SKScene = GameModePrecision(size: self.size)
            setStatGamer(self.player)
            scene.scaleMode = .AspectFill
            self.view?.presentScene(scene)
        }
        //        else if (player.gameMode == "survie")
        //        {
        //            let scene:SKScene = Survie(size: self.size)
        //            setStatGamer(self.player)
        //            scene.scaleMode = .AspectFill
        //            self.view?.presentScene(scene)
        //        }
    }
    
    
    func initSwiping(view: SKView) {
        let swipeRight:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: Selector("swiped:"))
        let swipeLeft:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: Selector("swiped:"))
        let swipeUp:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: Selector("swiped:"))
        let swipeDown:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: Selector("swiped:"))
        swipeRight.direction = .Right
        view.addGestureRecognizer(swipeRight)
        swipeLeft.direction = .Left
        view.addGestureRecognizer(swipeLeft)
        swipeUp.direction = .Up
        view.addGestureRecognizer(swipeUp)
        swipeDown.direction = .Down
        view.addGestureRecognizer(swipeDown)
    }
    
    func swiped(sender:UISwipeGestureRecognizer){
        if (canSwipe == true) {
            showHighscore()
        }
    }
    
    func showHighscore() -> Void
    {
        var canShow = false
        menuItem.forEach({ (item: MenuItem) -> () in
            if item.name == "item3" {
                if (item.isSelectable == true) {
                    canShow = true;
                }
            }
        })
        tabBallonHighscore.forEach { (item: Ballon) -> () in
            if (item.position.y > 800) {
                areShow = false
                canSwipe = true
                tabBallonHighscore.removeAtIndex(self.tabBallonHighscore.indexOf(item)!)
            }
        }
        if (areShow == false && canShow == true)
        {
            canSwipe = false
            
            for index in 1...3 {
                switch index {
                case 1:
                    areShow = true
                    // let color = randIntervalPositif(4, diff: 0, isForNeg: false)
                    let imgN = "star-fill\(level)"
                    let pos = pos1
                    //            pos.y += 400
                    let toGo = toGo1
                    let oscillate = SKAction.oscillation(amplitude: 5, timePeriod: 1, midPoint: pos)
                    let ball = Ballon(texture: SKTexture(imageNamed: imgN), nom: "ballon", pos: pos, size: size.width, level: 1, zpos: 4, toGo: toGo)
                    ball.position.y -= 55
                    let lab1 = SKLabelNode(fontNamed:"Copperplate-Bold")
                    let lab2 = SKLabelNode(fontNamed:"Copperplate-Bold")
                    
                    let toLabel = defautls.integerForKey(HighScoreKeyStandart)
                    lab1.text = "Highscore"
                    lab1.fontColor = SKColor.whiteColor()
                    lab1.fontSize = 10
                    lab1.position = ball.position
                    lab1.position.y += 10
                    lab1.zPosition = 5
                    lab2.fontColor = SKColor.whiteColor()
                    lab2.fontSize = 10
                    lab2.position = ball.position
                    lab2.zPosition = 5
                    lab2.text =  "\(toLabel)"
                    ball.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    ball.runAction(SKAction.moveByX(0, y: toGo.y + 55, duration: 3))
                    lab1.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    lab1.runAction(SKAction.moveByX(0, y: toGo.y + 55, duration: 3))
                    lab2.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    lab2.runAction(SKAction.moveByX(0, y: toGo.y + 55, duration: 3))
                    tabBallonHighscore.append(ball)
                    tabBallonLabel.append(lab1)
                    tabBallonLabel.append(lab2)
                    self.addChild(ball)
                    self.addChild(lab1)
                    self.addChild(lab2)
                    break
                case 2:
                    
                    let pos = pos2
                    // let color = randIntervalPositif(4, diff: 0, isForNeg: false)
                    let imgN = "star-fill\(level)"
                    //pos.y += 400
                    let toGo = toGo2
                    let ball = Ballon(texture: SKTexture(imageNamed:imgN), nom: "ballon", pos: pos, size: size.width, level: 1, zpos: 4, toGo: toGo)
                    ball.position.y -= 55
                    let lab1 = SKLabelNode(fontNamed:"Copperplate-Bold")
                    let lab2 = SKLabelNode(fontNamed:"Copperplate-Bold")
                    let toLabel = defautls.integerForKey(HighScoreKeyPrecision)
                    lab1.text = "Highscore"
                    lab1.fontColor = SKColor.whiteColor()
                    lab1.fontSize = 10
                    lab1.position = ball.position
                    lab1.position.y += 10
                    lab1.zPosition = 5
                    lab2.fontColor = SKColor.whiteColor()
                    lab2.fontSize = 10
                    lab2.position = ball.position
                    lab2.zPosition = 5
                    lab2.text =  "\(toLabel)"
                    let oscillate = SKAction.oscillation(amplitude: 5, timePeriod: 1, midPoint: pos)
                    ball.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    ball.runAction(SKAction.moveByX(0, y: toGo.y + 55, duration: 3))
                    lab1.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    lab1.runAction(SKAction.moveByX(0, y: toGo.y + 55, duration: 3))
                    lab2.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    lab2.runAction(SKAction.moveByX(0, y: toGo.y + 55, duration: 3))
                    tabBallonHighscore.append(ball)
                    tabBallonLabel.append(lab1)
                    tabBallonLabel.append(lab2)
                    self.addChild(ball)
                    self.addChild(lab1)
                    self.addChild(lab2)
                    break
                case 3:
                    
                    let pos = pos3
                    //  let color = randIntervalPositif(4, diff: 0, isForNeg: false)
                    let imgN = "star-fill\(level)"
                    // pos.y += 400
                    let toGo = toGo3
                    let ball = Ballon(texture: SKTexture(imageNamed: imgN), nom: "ballon", pos: pos, size: size.width, level: 1, zpos: 6, toGo: toGo)
                    ball.position.y -= 55
                    let lab1 = SKLabelNode(fontNamed:"Copperplate-Bold")
                    let lab2 = SKLabelNode(fontNamed:"Copperplate-Bold")
                    let toLabel = defautls.integerForKey(HighScoreKeySurvie)
                    lab1.text = "Highscore"
                    lab1.fontColor = SKColor.whiteColor()
                    lab1.fontSize = 10
                    lab1.position = ball.position
                    lab1.position.y += 10
                    lab1.zPosition = 7
                    lab2.fontColor = SKColor.whiteColor()
                    lab2.fontSize = 10
                    lab2.position = ball.position
                    lab2.zPosition = 7
                    lab2.text =  "\(toLabel)"
                    let oscillate = SKAction.oscillation(amplitude: 5, timePeriod: 1, midPoint: pos)
                    ball.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    ball.runAction(SKAction.moveByX(0, y: toGo.y + 155, duration: 3))
                    lab1.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    lab1.runAction(SKAction.moveByX(0, y: toGo.y + 155, duration: 3))
                    lab2.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                    lab2.runAction(SKAction.moveByX(0, y: toGo.y + 155, duration: 3), completion: { self.areShow = true; self.canSwipe = true})
                    tabBallonHighscore.append(ball)
                    tabBallonLabel.append(lab1)
                    tabBallonLabel.append(lab2)
                    self.addChild(ball)
                    self.addChild(lab1)
                    self.addChild(lab2)
                    break
                default:
                    break
                }
            }
        }
        else if (areShow == true)
        {
            canSwipe = false
            tabBallonHighscore.forEach({ (item: Ballon) -> () in
                item.runAction(SKAction.moveByX(0, y: +1000, duration:4))
            })
            tabBallonLabel.forEach({ (item: SKLabelNode) -> () in
                item.runAction(SKAction.moveByX(0, y: +1000, duration:4), completion: {self.canSwipe = true})
            })
        }
    }
    
    
}


