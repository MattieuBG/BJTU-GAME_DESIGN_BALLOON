//
//  MenuItem.swift
//  Balloon
//
//  Copyright © 2016 Mattieu BERNARD-GUÊLE. All rights reserved.
//

import Foundation
import SpriteKit

class MenuItem : SKSpriteNode {
    var isSelected : Bool = false
    var isSelectable : Bool = false
    var text : String = ""
    init(texture: SKTexture?, nom: String, pos: CGPoint, size: CGFloat, text: String, isSelected : Bool, isSelectable: Bool) {
        super.init(texture: texture, color: UIColor.blackColor(), size: texture!.size())
        self.name = nom
        self.position = pos
        self.text = text
        self.isSelected = isSelected
        self.isSelectable = isSelectable
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
