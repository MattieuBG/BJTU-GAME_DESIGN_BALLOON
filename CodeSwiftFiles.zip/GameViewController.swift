//
//  GameViewController.swift
//  SnakOs2.0
//
//  Copyright (c) 2016 Mattieu BERNARD-GUÊLE. All rights reserved.
//

import UIKit
import SpriteKit
import AVFoundation

var backgroundMusicPlayer:AVAudioPlayer = AVAudioPlayer()
var allNuagesFromController : [Nuages] = []
var player : Player = Player()
let defautls = NSUserDefaults.standardUserDefaults()

class GameViewController: UIViewController {
    
    let scene = Menu(fileNamed:"Menu")
    override func viewDidLoad() {
        super.viewDidLoad()
        let skView = self.view as! SKView
        //skView.showsFPS = true
        //skView.showsNodeCount = true
        skView.ignoresSiblingOrder = true
        scene!.scaleMode = .AspectFill
        skView.presentScene(scene)
    }
    
    override func shouldAutorotate() -> Bool {
        return true
    }
    
    override func supportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        if UIDevice.currentDevice().userInterfaceIdiom == .Phone {
            return .AllButUpsideDown
        } else {
            return .All
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
}

let π = CGFloat(M_PI)

extension SKAction {
    static func oscillation(amplitude a: CGFloat, timePeriod t: CGFloat, midPoint: CGPoint) -> SKAction {
        let action = SKAction.customActionWithDuration(Double(t)) { node, currentTime in
            let displacement = a * cos(2 * π * currentTime / t)
            node.position.x = midPoint.x + displacement
        }
        
        return action
    }
}

extension SKAction {
    static func oscillationHorizontale(amplitude a: CGFloat, timePeriod t: CGFloat, midPoint: CGPoint) -> SKAction {
        let action = SKAction.customActionWithDuration(Double(t))
            { node, currentTime in
                let displacement = a * sin(2 * π * currentTime / t)
                node.position.y = midPoint.y + displacement
        }
        
        return action
    }
}

func randIntervalPositif(range: UInt32, diff: UInt32?, isForNeg: Bool) -> CGFloat
{
    if (isForNeg == false) {
        var rand = arc4random_uniform(range)
        rand += diff!
        return CGFloat(rand)
    }
    else
    {
        var negrand = arc4random_uniform(range)
        negrand += diff!
        var negcgfloat = CGFloat(negrand)
        negcgfloat *= -1
        return negcgfloat
    }
}

func init_sound(sound: String, ext: String) -> Void {
    let bgMusicURL:NSURL = NSBundle.mainBundle().URLForResource(sound, withExtension: ext)!
    backgroundMusicPlayer = try!  AVAudioPlayer(contentsOfURL: bgMusicURL)
    backgroundMusicPlayer.numberOfLoops = -1
    backgroundMusicPlayer.prepareToPlay()
    backgroundMusicPlayer.play()
}

func setNuages(nuages: [Nuages]) -> Void
{
    allNuagesFromController = nuages
}

func getNuages() -> [Nuages]
{
    return allNuagesFromController
}

func setStatGamer(gamer: Player) -> Void
{
    player = gamer
}

func getStatGamer() -> Player
{
    return player
}