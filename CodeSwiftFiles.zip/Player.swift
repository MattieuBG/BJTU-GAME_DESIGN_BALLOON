//
//  Player.swift
//  Balloon
//
//  Copyright © 2016 Mattieu BERNARD-GUÊLE. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit
import AVFoundation

class Player {
    var HighScore : Int = 0
    var CurrentScore : Int
    let Duration : NSTimeInterval
    var gameMode : String
    var level: Int
    
    init() {
    HighScore = 0
    Duration = NSTimeInterval(60)
    CurrentScore = 0
    gameMode = ""
    level = 1
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
