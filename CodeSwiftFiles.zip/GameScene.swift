//
//  GameScene.swift
//  SnakOs2.0
//
//  Copyright (c) 2016 Mattieu BERNARD-GUÊLE. All rights reserved.
//

import SpriteKit
import UIKit
import AVFoundation
import AudioToolbox

class GameScene: SKScene {
    var allNuages : [Nuages] = []
    var gamer : Player = Player()
    var replay = MenuItem(texture: SKTexture(imageNamed:"itemR"), nom: "replay", pos: CGPointMake(1234, 1234), size: 1234,text: "replay", isSelected: false, isSelectable: false)
    
    var tabBallon: [Ballon] = []
    var checkBallon: [Ballon] = []
    let bgImage = SKSpriteNode(imageNamed: "ciel")
    let pausedImage = SKSpriteNode(imageNamed: "paused")
    let pausedbImage = SKSpriteNode(imageNamed: "pausedb")
    let backMenu = SKSpriteNode(imageNamed: "back")
    var score = SKLabelNode(fontNamed:"Copperplate-Bold")
    var timer = SKLabelNode(fontNamed:"Copperplate-Bold")
    var Mscore = SKLabelNode(fontNamed:"Copperplate-Bold")
    var Mtimer = SKLabelNode(fontNamed:"Copperplate-Bold")
    var High = SKLabelNode(fontNamed:"Copperplate-Bold")
    let playAgain = SKSpriteNode(imageNamed: "replay")
    var mess2 = SKLabelNode(fontNamed: "Copperplate-Bold")
    var callTime = NSTimer()
    var canSwitch = NSTimer()
    var HighScoreKey: String = "HighScoreKey"
    var devMess : String = "Backing menu"
    
    var time : Int = 0
    var newDelay = 1
    var timeToShow : Int = 30
    var cgfloat : CGFloat = 0.0
    var gameFinish : Bool = false
    var btnplayAgain : Bool = false
    var canChange : Bool = false
    var timeCreate : Int = 0
    
    
    override func didMoveToView(view: SKView) {
        /* Setup your scene here */
        
        bgImage.position = CGPointMake(self.size.width/2, self.size.height/2)
        bgImage.size = CGSizeMake(self.frame.size.width, self.frame.size.height)
        bgImage.zPosition = 0
        bgImage.name = "back"
        self.addChild(bgImage)
        
        allNuages = getNuages()
        allNuages.forEach { (item: Nuages) -> () in
            self.addChild(item)
        }
        
        init_sound("jeux", ext: "mp3")
        gamer = getStatGamer()
        timeToCreate()
        initSwiping(view)
        HighScoreKey += "\(player.level)"
        
        let Highscore = defautls.integerForKey(HighScoreKey)
        gamer.HighScore = Highscore
        if (gamer.gameMode == "standart")
        {
            score = createLabel("Copperplate-Bold", fontSize: 35, color: SKColor.blackColor(), text: "\(gamer.CurrentScore)", pos: CGPointMake(frame.width - 320, frame.height - 30), zpos: 10, name: "currentScore")
            
            timer = createLabel("Copperplate-Bold", fontSize: 35, color: SKColor.yellowColor(), text: "\(timeToShow)", pos: CGPointMake(frame.width - 700, frame.height - 30), zpos: 5, name: "timer")
            
            callTime = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "manageTimer", userInfo: nil, repeats: true)
            
            self.addChild(score)
            self.addChild(timer)
        }
        else
        {
            var add = NSTimer()
            add = NSTimer.scheduledTimerWithTimeInterval(0.2, target: self, selector: "addDot", userInfo: nil, repeats: true)
            add.timeInterval
            let mess = createLabel("Copperplate-Bold", fontSize: 20, color: SKColor.blackColor(), text: "In Development:", pos: CGPointMake(frame.width/2, frame.height/2 + 20), zpos: 10, name: "final")
            mess2 = createLabel("Copperplate-Bold", fontSize: 20, color: SKColor.blackColor(), text: devMess, pos: CGPointMake(frame.width/2, frame.height/2 - 20), zpos: 10, name: "final")
            self.addChild(mess)
            self.addChild(mess2)
            let scene:SKScene = Menu(size: self.size)
            let transition:SKTransition = SKTransition.fadeWithDuration(6)
            self.view?.presentScene(scene, transition: transition)
            scene.scaleMode = .AspectFill
        }
        
    }
    
    func addDot(){
        devMess += "."
        if (devMess.containsString("....."))
        {
            devMess = "Backing menu"
        }
        else {
            mess2.text = devMess
        }
    }
    
    func makeExplosion(ballon: SKNode, x: CGFloat, y: CGFloat)
    {
        let exp1 = SKTexture(imageNamed: "exp1")
        let exp2 = SKTexture(imageNamed: "exp2")
        let exp3 = SKTexture(imageNamed: "exp3")
        let exp4 = SKTexture(imageNamed: "exp4")
        let exp5 = SKTexture(imageNamed: "exp5")
        let exp6 = SKTexture(imageNamed: "exp6")
        
        let animateExplosion = SKAction.sequence([
            SKAction.waitForDuration(0, withRange: 0),
            SKAction.animateWithTextures([exp1,exp2,exp3,exp4,exp5,exp6], timePerFrame: 0.05)
            ])
        
        let Explosion = SKSpriteNode(imageNamed: "exp1")
        Explosion.xScale = x
        Explosion.yScale = y
        Explosion.zPosition = 4
        Explosion.position = CGPointMake(ballon.position.x, ballon.position.y + 10)
        if (ballon.name == "vert" || ballon.name == "jaune") {
            Explosion.runAction(SKAction.playSoundFileNamed("boom.mp3", waitForCompletion: false))
        }
        if (ballon.name == "rouge" || ballon.name == "bleue") {
            Explosion.runAction(SKAction.playSoundFileNamed("boom2.mp3", waitForCompletion: false))
        }
        else if (ballon.name == "gris") {
            Explosion.runAction(SKAction.playSoundFileNamed("bombe.mp3", waitForCompletion: false))
        }
        else if (ballon.name == "replay") {
            //Explosion.runAction(SKAction.playSoundFileNamed("bombe.mp3", waitForCompletion: false))
            Explosion.runAction(SKAction.playSoundFileNamed("boom.mp3", waitForCompletion: false))
            
        }
        else if (ballon.name == "rose") {
            Explosion.runAction(SKAction.playSoundFileNamed("boom3.mp3", waitForCompletion: false))
        }
        self.addChild(Explosion)
        Explosion.runAction(animateExplosion, completion : {Explosion.removeFromParent()})
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        /* Called when a touch begins */
        
        for touch in touches {
            let location = touch.locationInNode(self)
            let node = self.nodeAtPoint(location)
            let nodes = self.nodesAtPoint(location)
            
            if (nodes.count >= 2)
            {
                if (nodes.first?.name == "vert") {
                    nodes.first!.removeFromParent()
                    makeExplosion((nodes.first)!, x: 0.5, y: 0.5)
                    
                    gamer.CurrentScore += 1
                    score.text = "\(gamer.CurrentScore)"
                }
                else if (nodes.first?.name == "bleue") {
                    makeExplosion((nodes.first)!, x: 0.5, y: 0.5)
                    nodes.first!.removeFromParent()
                    gamer.CurrentScore += 1
                    score.text = "\(gamer.CurrentScore)"
                }
                else if (nodes.first?.name == "rouge") {
                    makeExplosion((nodes.first)!, x: 0.5, y: 0.5)
                    nodes.first!.removeFromParent()
                    gamer.CurrentScore += 1
                    score.text = "\(gamer.CurrentScore)"
                }
                else if (nodes.first?.name == "jaune") {
                    makeExplosion((nodes.first)!, x: 0.5, y: 0.5)
                    nodes.first!.removeFromParent()
                    gamer.CurrentScore += 1
                    score.text = "\(gamer.CurrentScore)"
                }
                else if (nodes.first?.name == "gris") {
                    nodes.first!.removeFromParent()
                    self.scene?.removeAllChildren()
                    gamer.CurrentScore -= 3
                    postExplosionScreen()
                    makeExplosion((nodes.first)!, x: 2, y: 2)
                }
                else if (nodes.first?.name == "rose") {
                    makeExplosion((nodes.first)!, x: 0.3, y: 0.3)
                    nodes.first!.removeFromParent()
                    gamer.CurrentScore += 5
                    score.text = "\(gamer.CurrentScore)"
                }
                else if (nodes.first?.name == "goback")
                {
                    pausedImage.removeFromParent()
                    Mscore.removeFromParent()
                    Mtimer.removeFromParent()
                    pausedbImage.removeFromParent()
                    backMenu.removeFromParent()
                    High.removeFromParent()
                    playAgain.removeFromParent()
                    callTime = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "manageTimer", userInfo: nil, repeats: true)
                    
                    self.scene?.paused = false
                }
                else if (nodes.first?.name == "gomenu")
                {
                    let scene:SKScene = Menu(size: self.size)
                    scene.scaleMode = .AspectFill
                    let transition:SKTransition = SKTransition.fadeWithDuration(2)
                    self.view?.presentScene(scene, transition: transition)
                    self.scene?.paused = false
                }
                else if (nodes.first?.name == "playagain")
                {
                    self.scene?.paused = false
                    gamer.CurrentScore = 0
                    timeToShow = 30
                    setNuages(allNuages)
                    self.allNuages.forEach({ (item: Nuages) -> () in
                        item.removeFromParent()
                    })
                    let scene:SKScene = GameScene(size: self.size)
                    self.view?.presentScene(scene)
                    scene.scaleMode = .AspectFill
                }
            }
            if (node.name == "replay" && replay.isSelectable == true)
            {
                makeExplosion((nodes.first)!, x: 1, y: 1)
                node.removeFromParent()
                gamer.CurrentScore = 0
                replay.isSelected = true
                newDelay = 1
            }
        }
    }
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
        
        allNuages.forEach { (item: Nuages) -> () in
            let cgfloat2 = randIntervalPositif(650, diff: 40, isForNeg: false)
            let duration : NSTimeInterval = NSTimeInterval(randIntervalPositif(21, diff: 4, isForNeg: false))
            let ampli : CGFloat = randIntervalPositif(4, diff: 1, isForNeg: false)
            
            if (item.position.x >= CGFloat(950) && item.name?.containsString("1") == nil && item.isFinish == true){
                goLeftOrRight(item, rand: cgfloat2, ampli: ampli, time: 5, mid: CGPointMake(item.position.x, cgfloat2), x: 0, duration: duration)
            }
            else if (item.position.x >= CGFloat(1000) && item.isFinish == true){
                goLeftOrRight(item, rand: cgfloat2, ampli: ampli, time: 5, mid: CGPointMake(item.position.x, cgfloat2), x: 0, duration: duration)
            }
            if (item.position.x <= CGFloat(50) && item.isFinish == true){
                goLeftOrRight(item, rand: cgfloat2, ampli: ampli, time: 5, mid: CGPointMake(item.position.x, cgfloat2), x: 1024, duration: duration)
            }
            if (item.position.x >= CGFloat(100) && item.position.x <= CGFloat(900)){
                item.isFinish = true
            }
            
        }
        
        checkBallon.forEach { (item: Ballon) -> () in
            if (item.position.y >= size.height + 30 && item.name != "gris" && item.name != "rose") {
                //item.runAction(SKAction.playSoundFileNamed("boom.mp3", waitForCompletion: true))
                checkBallon.removeAtIndex(checkBallon.indexOf(item)!)
                item.removeFromParent()
                if (player.CurrentScore != 0) {
                    player.CurrentScore -= 1
                }
                else {
                    player.CurrentScore = 0
                }
                score.text = "\(player.CurrentScore)"
            }
        }
        
        if (gameFinish == false)
        {
            if (time % timeCreate == 0)
            {
                if (randIntervalPositif(131, diff: 0, isForNeg: false) % 3 == 0/*time % 40 == 0*/)
                {
                    let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                    let pos = CGPointMake(cgfloat, -55)
                    let test = Ballon(texture: SKTexture(imageNamed:"vert"), nom: "vert", pos: pos, size: size.width, level: gamer.level)
                    checkBallon.append(test)
                    self.addChild(test)
                }
                else if (randIntervalPositif(131, diff: 0, isForNeg: false) % 3 == 0/*time % 30 == 0*/)
                {
                    let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                    let pos = CGPointMake(cgfloat, -55)
                    let test = Ballon(texture: SKTexture(imageNamed:"bleu"), nom: "bleue", pos: pos, size: size.width, level: gamer.level)
                    checkBallon.append(test)
                    self.addChild(test)
                }
                else if (randIntervalPositif(131, diff: 0, isForNeg: false) % 3 == 0/*time % 35 == 0*/)
                {
                    let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                    let pos = CGPointMake(cgfloat, -55)
                    let test = Ballon(texture: SKTexture(imageNamed:"jaune"), nom: "jaune", pos: pos, size: size.width, level: gamer.level)
                    checkBallon.append(test)
                    self.addChild(test)
                }
                else if (randIntervalPositif(131, diff: 0, isForNeg: false) % 3 == 0/*time % 50 == 0*/)
                {
                    let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                    let pos = CGPointMake(cgfloat, -55)
                    let test = Ballon(texture: SKTexture(imageNamed:"rouge"), nom: "rouge", pos: pos, size: size.width, level: gamer.level)
                    checkBallon.append(test)
                    self.addChild(test)
                }
                else if (randIntervalPositif(131, diff: 0, isForNeg: false) % 11 == 0/*time % 45 == 0*/)
                {
                    let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                    let pos = CGPointMake(cgfloat, -60)
                    let test = Ballon(texture: SKTexture(imageNamed:"rose"), nom: "rose", pos: pos, size: size.width, level: gamer.level)
                    checkBallon.append(test)
                    self.addChild(test)
                }
                else if (randIntervalPositif(141, diff: 0, isForNeg: false) % 7 == 0/*time % 25 == 0*/)
                {
                    let cgfloat = randIntervalPositif(376, diff: 325, isForNeg: false)
                    let pos = CGPointMake(cgfloat, -80)
                    let test = Ballon(texture: SKTexture(imageNamed:"gris"), nom: "gris", pos: pos, size: size.width, level: gamer.level)
                    checkBallon.append(test)
                    self.addChild(test)
                }
            }
            
            
        }
        else
        {
            if (btnplayAgain == false)
            {
                let toGo = CGPointMake(size.width/2, size.height/1.5 - 50)
                let pos = CGPointMake(size.width/2, size.height/1.5 - 50 - 650)
                replay = MenuItem(texture: SKTexture(imageNamed:"playagain"), nom: "replay", pos: CGPointMake(size.width/2, size.height/1.5 - 50 - 650), size: size.width,text: "replay", isSelected: false, isSelectable: false)
                let oscillate = SKAction.oscillation(amplitude: 5, timePeriod: 1, midPoint: pos)
                replay.runAction(SKAction.repeatActionForever(oscillate), completion: { })
                replay.runAction(SKAction.moveByX(0, y: toGo.x + 230, duration: 5),completion : {self.replay.isSelectable = true})
                replay.zPosition = 4
                replay.xScale = 1.4
                replay.yScale = 1.2
                btnplayAgain = true
                self.addChild(replay)
            }
        }
        time++
    }
    
    func goLeftOrRight(obj: Nuages, rand: CGFloat, ampli : CGFloat, time: CGFloat, mid: CGPoint, x: CGFloat, duration: NSTimeInterval) -> Void
    {
        obj.removeAllActions()
        let pos = CGPointMake(obj.position.x, cgfloat)
        obj.position = pos
        obj.isFinish = false
        let oscillate = SKAction.oscillationHorizontale(amplitude: ampli, timePeriod: time, midPoint: mid)
        obj.runAction(SKAction.repeatActionForever(oscillate))
        obj.runAction(SKAction.moveToX(x, duration: duration))
    }
    
    func initializeNuage()
    {
        if allNuages.count >= 1 {
            allNuages.removeAll()
        }
        for index in 1...6 {
            cgfloat = randIntervalPositif(650, diff: 40, isForNeg: false)
            let randomize = randIntervalPositif(10, diff: 1, isForNeg: false)
            var pos = CGPointMake(30, cgfloat)
            if (randomize % 2 == 0) {
                pos = CGPointMake(30, cgfloat)
            }
            else {
                pos = CGPointMake(1000, cgfloat)
            }
            let nuage = Nuages(texture: SKTexture(imageNamed:"nu\(index)"), nom: "nuage\(index)", pos: pos, size: size.width)
            nuage.zPosition = 1
            nuage.xScale = 3
            nuage.yScale = 3
            allNuages.append(nuage)
        }
        
        allNuages.forEach { (item: Nuages) -> () in
            self.addChild(item)
        }
    }
    
    func postExplosionScreen()
    {
        allNuages.forEach { (item: Nuages) -> () in
            self.addChild(item)
        }
        
        score.text = "\(gamer.CurrentScore)"
        bgImage.position = CGPointMake(self.size.width/2, self.size.height/2)
        bgImage.size = CGSizeMake(self.frame.size.width, self.frame.size.height)
        bgImage.zPosition = 0
        addChild(bgImage)
        addChild(score)
        addChild(timer)
    }
    
    func manageTimer()
    {
        var canEnter = true
        if (timeToShow != 0)
        {
            timeToShow -= 1
        }
        else
        {
            canEnter = false
        }
        timer.text = "\(timeToShow)"
        
        if (timeToShow == 10) {
            timer.fontColor = SKColor.redColor()
        }
        if (timeToShow == 5) {
            timer.runAction(SKAction.playSoundFileNamed("countdown.mp3", waitForCompletion: false))
        }
        if (timeToShow == 0 && canEnter == true) {
            let score = "Final score: \(gamer.CurrentScore)"
            if (defautls.integerForKey(HighScoreKey) < gamer.CurrentScore) {
                defautls.setInteger(gamer.CurrentScore, forKey: HighScoreKey)
                defautls.synchronize()
                gamer.HighScore = gamer.CurrentScore
            }
            if (defautls.integerForKey(HighScoreKey) == 0) {
                defautls.setInteger(gamer.CurrentScore, forKey: HighScoreKey)
                defautls.synchronize()
                gamer.HighScore = gamer.CurrentScore
            }
            setStatGamer(gamer)
            self.removeAllChildren()
            allNuages.forEach({ (item: Nuages) -> () in
                self.addChild(item)
            })
            
            let final = createLabel("Copperplate-Bold", fontSize: 20, color: SKColor.blackColor(), text: score, pos: CGPointMake(frame.width/2, frame.height/2 - 20), zpos: 10, name: "final")
            let highScore = createLabel("Copperplate-Bold", fontSize: 20, color: SKColor.blackColor(), text: "Your Highscore is: \(defautls.integerForKey(HighScoreKey))", pos: CGPointMake(frame.width/2, frame.height/2 - 50), zpos: 10, name: "highscore")
            
            
            addChild(bgImage)
            addChild(final)
            addChild(highScore)
            gameFinish = true;
        }
        if (gameFinish == true && newDelay != 0)
        {
            newDelay += 1
            if (newDelay > 6) {
                replay.isSelectable = true
                newDelay = 0
            }
            if (defautls.integerForKey(HighScoreKey) < gamer.CurrentScore) {
                defautls.setInteger(gamer.CurrentScore, forKey: HighScoreKey)
                defautls.synchronize()
            }
            if (newDelay >= 2 && replay.isSelected == true) {
                setNuages(allNuages)
                newDelay = 0
                self.allNuages.forEach({ (item: Nuages) -> () in
                    item.removeFromParent()
                })
                let scene:SKScene = GameScene(size: self.size)
                self.view?.presentScene(scene)
                scene.scaleMode = .AspectFill
            }
        }
        //time++
    }
    
    func createLabel(fontName: String, fontSize: Int, color: SKColor, text: String, pos: CGPoint, zpos: CGFloat, name: String) -> SKLabelNode
    {
        let label = SKLabelNode(fontNamed: fontName)
        label.fontSize = 20
        label.fontColor = color
        label.text = text
        label.position = pos
        label.zPosition = zpos
        label.name = name
        return label
    }
    
    func timeToCreate() -> Void
    {
        if (gamer.level == 1){
            timeCreate = 40
        }
        else if (gamer.level == 2){
            timeCreate = 35
        }
        else if (gamer.level == 3){
            timeCreate = 30
        }
        else if (gamer.level == 4){
            timeCreate = 20
        }
        else if (gamer.level == 5){
            timeCreate = 10
        }
    }
    
    func initSwiping(view: SKView) {
        let swipeRight:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: Selector("swiped:"))
        let swipeLeft:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: Selector("swiped:"))
        let swipeUp:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: Selector("swiped:"))
        let swipeDown:UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: Selector("swiped:"))
        swipeRight.direction = .Right
        view.addGestureRecognizer(swipeRight)
        swipeLeft.direction = .Left
        view.addGestureRecognizer(swipeLeft)
        swipeUp.direction = .Up
        view.addGestureRecognizer(swipeUp)
        swipeDown.direction = .Down
        view.addGestureRecognizer(swipeDown)
    }
    
    func swiped(sender:UISwipeGestureRecognizer){
        if (self.scene?.paused == false) {
            pausedImage.position = CGPointMake(self.size.width/2, self.size.height/2)
            pausedImage.size = CGSizeMake(self.frame.size.width, self.frame.size.height)
            pausedImage.zPosition = 15
            pausedImage.name = "pause"
            pausedbImage.position = CGPointMake(self.size.width/2, self.size.height/2 + 300)
            pausedbImage.zPosition = 16
            pausedbImage.xScale = 3
            pausedbImage.yScale = 3
            pausedbImage.name = "goback"
            backMenu.position = CGPointMake(self.size.width/2 - 175, self.size.height/2 - 346)
            backMenu.zPosition = 16
            backMenu.xScale = 1
            backMenu.yScale = 1
            backMenu.name = "gomenu"
            
            playAgain.position = CGPointMake(self.size.width/2 + 175, self.size.height/2 - 346)
            playAgain.zPosition = 16
            playAgain.xScale = 1.6
            playAgain.yScale = 1.6
            playAgain.name = "playagain"
            
            High = createLabel("Copperplate-Bold", fontSize: 24, color: SKColor.blackColor(), text: "Your Highscore is: \(defautls.integerForKey(HighScoreKey))", pos: CGPointMake(frame.width/2, frame.height/2 + 180 ), zpos: 10, name: "highscore")
            Mscore =  createLabel("Copperplate-Bold", fontSize: 20, color: SKColor.whiteColor(), text: "Current score: \(gamer.CurrentScore)", pos: CGPointMake(frame.width/2, frame.height/2 + 130 ), zpos: 10, name: "score")
            Mtimer = createLabel("Copperplate-Bold", fontSize: 20, color: SKColor.whiteColor(), text: "Time left: \(self.timeToShow)", pos: CGPointMake(frame.width/2, frame.height/2 + 100), zpos: 10, name: "temps")
            Mtimer.zPosition = 16
            Mscore.zPosition = 16
            self.addChild(pausedImage)
            self.addChild(Mscore)
            self.addChild(Mtimer)
            self.addChild(pausedbImage)
            self.addChild(backMenu)
            self.addChild(playAgain)
            self.addChild(High)
            callTime.invalidate()
            self.scene?.paused = true
        }
        else {
            pausedImage.removeFromParent()
            Mscore.removeFromParent()
            Mtimer.removeFromParent()
            pausedbImage.removeFromParent()
            backMenu.removeFromParent()
            High.removeFromParent()
            playAgain.removeFromParent()
            callTime = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "manageTimer", userInfo: nil, repeats: true)
            self.scene?.paused = false
        }
    }
}
